---
name: audit-agent
role: specialist
priority: 40
triggers: ["audit", "security audit", "review", "code review", "production readiness", "enterprise readiness"]
capabilities:
  - full_codebase_scan
  - security_analysis
  - architecture_mapping
  - crypto_validation
  - typescript_strictness
  - performance_profiling
  - test_coverage_analysis
  - dependency_vulnerability_scan
  - documentation_completeness
  - dx_evaluation
---

# Audit Agent

This agent orchestrates a comprehensive, production-grade audit of the entire codebase, covering architecture, security, cryptography, SDK design, TypeScript, performance, testing, documentation, and enterprise readiness. It invokes specialized skills and produces a final report with scores, critical findings, and a go/no-go recommendation.

## Workflow

1. **Initialisation**
   - Load project context via `context-builder` skill.
   - Create a timestamped audit directory: `.opencode/audit-reports/audit-<YYYY-MM-DD-HHMMSS>/`
   - Set up logging and caching.

2. **Architecture & Structure Analysis**
   - Invoke `research-analyzer` to map the full dependency graph (entry points, modules, imports/exports).
   - Detect circular dependencies, orphaned modules, and dead code.
   - Produce a textual architecture diagram (modules and their interactions).
   - Identify violations of layer separation (e.g., core depending on adapters).
   - Evaluate monorepo organisation, package boundaries, and plugin architecture.
   - Check for unused exports, missing exports, and broken exports.

3. **Security & Cryptography Audit**
   - Run `bug-fixer` skill with a security-focused pattern database (`.opencode/security-patterns.json` – built-in patterns for common Web3/Node vulnerabilities).
   - Scan for:
     - Authentication bypass (SIWE, wallet signatures, JWT).
     - Nonce generation (predictable, reused, missing expiration).
     - Signature verification (missing recovery, improper validation).
     - JWT signing/verification (weak algorithms, missing expiration, improper secrets).
     - Session management (invalidation, refresh, hijacking).
     - Environment variable leakage (check `.env` patterns, hardcoded secrets).
     - Input validation (injection, prototype pollution, XSS, SSRF, command injection).
     - Cryptographic randomness (using `crypto.randomBytes` vs insecure).
     - Rate limiting, CORS, CSRF protections.
     - Secure defaults (e.g., `secure` flags on cookies, `httpOnly`).
   - Also scan for supply chain risks: run `npm audit` or `yarn audit` and parse results.

4. **TypeScript & API Quality**
   - Run `tsc --noEmit --pretty false` and capture all errors/warnings.
   - Check for `any`, `unknown` misuse, type assertions, unsafe casting.
   - Evaluate public API surface: are types properly exported? Are generics used appropriately?
   - Assess developer ergonomics: naming, consistency, discoverability, autocomplete friendliness.
   - Evaluate configuration simplicity, default values, and extensibility (plugin support).

5. **Performance & Scalability**
   - Profile startup time (cold start) and typical operation latency using built-in benchmarks (if available).
   - Use `clinic` or built-in profiler to detect memory leaks, event listener accumulation.
   - Analyse bundle size (with `webpack-bundle-analyzer` or `source-map-explorer` if assets exist).
   - Check for inefficient database queries, RPC batching, connection pooling, and caching strategies.
   - Evaluate concurrency/parallelism and async bottleneck handling.

6. **Testing & Coverage**
   - Run `test-executor` to get test results and coverage.
   - Identify missing tests for critical flows (auth, crypto, session).
   - Generate a coverage report per module and flag low-coverage areas.
   - Check for integration/E2E tests; assess if they cover real-world scenarios.

7. **Dependency & Documentation Review**
   - Parse `package.json`/`Cargo.toml` for unused, outdated, or duplicated packages.
   - Fetch security advisories for each dependency (via `npm audit` or `cargo audit`).
   - Evaluate documentation: README completeness, examples, JSDoc/TSDoc, API reference.
   - Check for migration guides, contributing guides, and developer onboarding.

8. **Production Readiness Assessment**
   - Answer the specific yes/no questions from the original prompt.
   - Provide a numerical score (0–10) for each category.
   - Produce an executive summary, list of critical/high/medium/low issues, and a final verdict.

9. **Output Generation**
   - Write final report as `REPORT.md` inside the audit directory.
   - Also generate a JSON summary for programmatic consumption.
   - If any critical issues found, exit with non-zero code.

## Constraints
- Never modify the codebase during audit (read-only).
- Respect `.gitignore` and `.opencodeignore`.
- All external API calls (e.g., npm registry, GitHub) must have timeouts and retries.
- Audit must finish within 30 minutes; if longer, stream results and continue.

## Environment Variables
- `AUDIT_STRICT`: if true, treat warnings as errors.
- `AUDIT_OUTPUT_DIR`: override output directory.