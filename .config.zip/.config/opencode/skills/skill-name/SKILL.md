---
name: skill-name
description: General-purpose utility skill with file watching, event handling, and batch processing
version: 2.0
---

# Utility Skill

This skill provides a wide range of helper functions for file manipulation, system monitoring, and data transformation.

## Trigger
- User mentions "utility", "batch", "watch", "convert", "extract".
- Or when no other skill matches and the task is generic.

## Capabilities

### File Watching
- Monitor directories for changes (create, modify, delete).
- Trigger custom commands on events (e.g., restart server, run lint).
- Configuration via `.opencode/watcher-config.json`.

### Batch Processing
- Process multiple files with a given pattern (e.g., all `.txt` files).
- Apply transformations: sed, awk, jq, custom scripts.
- Output to a separate directory with same structure.

### Data Extraction
- Extract structured data from logs, CSVs, JSON.
- Convert between formats (JSON ↔ XML ↔ YAML).
- Summarize data (counts, averages, percentiles).

### System Utilities
- Check disk usage, memory, CPU.
- Kill stuck processes (by port or PID).
- Archive/compress directories (tar, zip).

### Notification
- Send alerts via desktop notification, Slack webhook, or email.

### Scheduling
- Schedule recurring tasks (cron-like) using `.opencode/schedule.json`.

## Workflow
1. Parse user request for keywords: "watch", "batch", "convert", "monitor", "schedule".
2. If "watch" – set up a file watcher with `fs.watch` (Node) or `inotifywait` (Linux).
3. If "batch" – scan directory, apply operation, report results.
4. If "convert" – detect input format, convert to target, save.
5. If "monitor" – run system checks and log to `.opencode/monitor.log`.
6. If "schedule" – add/remove cron entries (using `cron` or `task scheduler`).

## Constraints
- Do not modify system files outside the project.
- For scheduling, use user-level crontab (not system).
- For notifications, require configuration in `.opencode/notify-config.json`.

## Example Usage
- User: "Watch src/ and restart server on changes"
  → Skill sets up watcher with `npm run restart` on change.

- User: "Convert all .json files in data/ to .yaml"
  → Skill uses `yaml` library to convert and save in data/yaml/.

## Output
- For file operations: list of processed files and status.
- For monitoring: resource usage summary.
- For scheduling: confirmation of scheduled task.