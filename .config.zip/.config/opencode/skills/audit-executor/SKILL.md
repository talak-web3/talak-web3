---
name: audit-executor
description: Core skill that performs the detailed audit steps, invoked by audit-agent
version: 1.0
---

# Audit Executor

This skill implements the actual audit logic, using other skills as building blocks. It is invoked by the `audit-agent` and orchestrates the entire workflow.

## Capabilities

### Architecture & Dependency Analysis
- Use `research-analyzer` to:
  - Build a full dependency graph (depth unlimited).
  - Detect cycles, orphan modules, and unused exports.
  - Generate a text-based architecture diagram.
- Also run `deep-executor` to run custom scripts (e.g., `madge` for circular dependencies, `depcheck` for unused dependencies).

### Security & Cryptographic Validation
- Use `bug-fixer` with a comprehensive security pattern library (embedded in the skill):
  - Patterns for SIWE/EIP-4361: nonce length, expiration, signature verification.
  - JWT: algorithm (must be RS256/ES256, not HS256), secret storage, expiration.
  - Input sanitisation: regex injection, SQL/NoSQL injection, prototype pollution.
  - Environment: hardcoded secrets, `process.env` exposure.
  - Randomness: checks for `crypto.randomBytes`, `uuidv4`, etc.
- Additionally, run static analysis for security-sensitive functions (e.g., `eval`, `child_process.exec`).
- Use `npm audit`/`yarn audit` and parse output to flag vulnerable dependencies.

### TypeScript & API Quality
- Execute `tsc --noEmit` and parse diagnostics.
- Count uses of `any`, `as`, `// @ts-ignore`; flag excessive usage.
- Validate public exports: ensure all exported types/interfaces have JSDoc.
- Evaluate consistency of method signatures, error types, and option objects.

### Performance Profiling
- If not in `--quick` mode, run:
  - `node --cpu-prof` or `clinic doctor` on a sample script exercising core SDK functions.
  - Measure bundle size using `source-map-explorer` or `webpack-bundle-analyzer`.
  - Check for memory leaks by running a loop and monitoring heap snapshots.
- Report any hotspots, large dependencies, or excessive object allocations.

### Testing & Coverage
- Invoke `test-executor` to run full test suite and get coverage.
- If coverage is <80% on critical modules, flag as high risk.
- Identify missing tests for specific security-sensitive paths.

### Documentation & DX
- Scan README, docs/ folder, and JSDoc comments for completeness.
- Check if all public APIs are documented.
- Evaluate the installation and quick-start flow (does it work?).
- Assess error messages: are they actionable and clear?

### Report Generation
- Compile all findings into a structured object:
  - Issues: each with severity, file, line, category, root cause, impact, recommended fix, confidence.
  - Scores for each category (0–10).
  - Yes/No answers for the production readiness questions.
  - Executive summary and final verdict.
- Format the report according to the `format` argument (markdown, JSON, or HTML).

## Workflow (as called by audit-agent)

1. Accept parameters: `severity_filter`, `output_dir`, `format`, `quick_mode`, `no_cache`.
2. Create output subdirectory with timestamp.
3. Run `context-builder` to initialise project state.
4. **Architecture Phase**:
   - Run `research-analyzer` with `depth=10` and `format=json`.
   - Parse output to detect cycles, orphan modules, and dead code.
   - Generate a DOT or textual graph.
5. **Security Phase**:
   - Run `bug-fixer` with a special security pattern set (embedded in the skill).
   - Also perform custom scans using `grep` for known bad patterns.
   - Run dependency auditor.
6. **TypeScript Phase**:
   - Run `tsc` and capture output.
   - Also run `eslint` with recommended rules if available.
7. **Performance Phase** (skip if quick):
   - Run a simple performance benchmark (e.g., measure wallet signature generation 1000 times).
   - Use `process.memoryUsage()` before/after.
   - Calculate bundle size.
8. **Testing Phase**:
   - Run `test-executor` and parse coverage.
   - If coverage data is missing, flag.
9. **Documentation Phase**:
   - Check existence of README, CONTRIBUTING, API docs.
   - Count documented functions vs total exports.
10. **DX Phase**:
    - Evaluate the configuration API: number of required fields, sensible defaults.
    - Assess error classes and error messages.
11. **Scoring & Reporting**:
    - Aggregate scores for each domain based on issue counts and severity.
    - Answer final yes/no questions.
    - Write report files.
12. Return summary to the audit-agent.

## Embedded Security Pattern Database (excerpt)
```json
{
  "patterns": [
    { "id": "SEC001", "description": "Hardcoded secret", "regex": "secret\\s*=\\s*['\"][^'\"]+['\"]", "severity": "critical" },
    { "id": "SEC002", "description": "Insecure JWT algorithm", "regex": "algorithm\\s*:\\s*['\"]HS256['\"]", "severity": "high" },
    { "id": "SEC003", "description": "Nonce not stored or not checked", "regex": "nonce\\s*=.*\\n(?!.*verify)", "severity": "critical" },
    { "id": "SEC004", "description": "Prototype pollution via merge", "regex": "Object\\.assign\\([^,]+,\\s*req\\.body\\)", "severity": "high" },
    { "id": "SEC005", "description": "Unsafe eval", "regex": "eval\\(", "severity": "critical" }
  ]
}