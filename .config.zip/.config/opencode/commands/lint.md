---
name: lint
description: Run linters and formatters
arguments:
  - name: fix
    type: boolean
    required: false
    default: false
    description: "Automatically fix fixable issues"
  - name: format
    type: boolean
    required: false
    default: false
    description: "Run formatter (prettier, black, gofmt)"
  - name: strict
    type: boolean
    required: false
    default: false
    description: "Enable strict checks (warnings as errors)"
---

# Lint Command

## Execution
- Based on language: ESLint, PyLint, golangci-lint, cargo clippy, etc.
- For fix: append `--fix` or `--apply`.
- For format: run prettier, black, gofmt, rustfmt.
- For strict: set `--max-warnings 0` or similar.
- Output results in a structured format (JSON) and save to `.opencode/lint-<timestamp>.json`.

## Post-processing
- If any error, exit with non-zero.
- Summarise number of errors, warnings, fixable issues.

## Aliases
- `l` (short)
- `lf` (lint with fix)

## Hooks
- Pre-lint: run `.opencode/hooks/pre-lint.sh` if exists.