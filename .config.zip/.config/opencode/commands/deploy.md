---
name: deploy
description: Deploy application to various environments
arguments:
  - name: environment
    type: choice
    required: true
    choices: ["staging", "production", "preview"]
    description: "Target environment"
  - name: version
    type: string
    required: false
    description: "Specific version/tag to deploy"
  - name: dry-run
    type: boolean
    required: false
    default: false
    description: "Simulate deployment without actual changes"
  - name: skip-tests
    type: boolean
    required: false
    default: false
    description: "Skip test execution before deploy"
  - name: rollback
    type: boolean
    required: false
    default: false
    description: "Rollback to previous version (use with environment)"
---

# Deploy Command

## Workflow
1. Ensure git working tree is clean (unless `--force`).
2. If not skipping tests, run the `test` command first.
3. Determine deployment method from project configuration (e.g., `deploy.sh`, `docker-compose`, `kubectl`, `aws`).
4. For staging:
   - Build artifacts: `npm run build:staging`.
   - Deploy to staging server (defined in `.opencode/deploy-config.json`).
   - Run health check endpoint.
5. For production:
   - Require explicit confirmation (`opencode confirm --level=high`).
   - Build with production flags.
   - Deploy with zero-downtime (blue-green or canary).
   - Monitor logs for errors for 5 minutes.
6. For preview:
   - Create a ephemeral environment based on current branch.
   - Use `preview` subdomain.
7. After deployment, update deployment status in `.opencode/deploy-state.json`.
8. Notify via Slack or email if configured.

## Rollback
- If `--rollback` provided, revert to the previous successful deployment state.
- Uses versioned artifacts or database migration rollback.

## Constraints
- Require user confirmation for production deployments.
- Do not deploy with failing tests.
- Ensure all environment variables are correctly set (validate against `.env.example`).

## Output