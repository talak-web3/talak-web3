---
name: research
description: Perform deep codebase and external research
arguments:
  - name: query
    type: string
    required: true
    description: "Search term or symbol name"
  - name: type
    type: choice
    required: false
    choices: ["code", "docs", "dependencies", "history"]
    default: "code"
    description: "Type of research"
  - name: depth
    type: integer
    required: false
    default: 3
    description: "Depth of dependency/call graph traversal"
  - name: format
    type: choice
    required: false
    choices: ["text", "json", "dot"]
    default: "text"
    description: "Output format"
---

# Research Command

## Execution
- For type `code`:
  - Invoke `research-analyzer` skill with the query.
  - Perform static analysis to find definitions, references, callers, callees.
- For type `docs`:
  - Search local documentation (`README.md`, `docs/` folder).
  - If network allowed, search npm, crates.io, pypi for official docs.
- For type `dependencies`:
  - Show dependency tree (direct and transitive) up to depth.
  - Highlight versions, licenses, known vulnerabilities.
- For type `history`:
  - Run `git log --grep=<query>`, `git blame` on files matching query.
  - Show authors, timestamps, commit messages.

## Output Format
- `text`: Human-readable bulleted lists.
- `json`: Structured JSON for programmatic consumption.
- `dot`: Graphviz DOT format for visualisation.

## Storage
- Save output to `.opencode/research-<query>-<timestamp>.md` (or .json/.dot).
- Cache results for 1 hour to avoid repeated computation.

## Aliases
- `rs` (short)
- `rsc` (research code)
- `rsd` (research dependencies)

## Errors
- If query too broad, prompt for narrowing.
- If no results, suggest using `grep` or `git log` manually.