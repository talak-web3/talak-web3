---
name: audit
description: Run a comprehensive codebase audit (security, architecture, performance, etc.)
arguments:
  - name: severity
    type: choice
    required: false
    choices: ["all", "critical", "high", "medium", "low"]
    default: "all"
    description: "Minimum severity to report"
  - name: output
    type: string
    required: false
    default: ".opencode/audit-reports"
    description: "Output directory for the report"
  - name: format
    type: choice
    required: false
    choices: ["markdown", "json", "html"]
    default: "markdown"
    description: "Report format"
  - name: quick
    type: boolean
    required: false
    default: false
    description: "Skip performance profiling and deep crypto analysis for faster run"
  - name: no-cache
    type: boolean
    required: false
    default: false
    description: "Disable caching of AST and dependency results"
---

# Audit Command

## Execution
- This command invokes the `audit-agent` to perform the full audit.
- Pass arguments as environment variables or via the agent's context.
- The agent will run all checks and produce a report.
- If `--quick` is set, the agent skips time-intensive steps (profiling, full crypto validation).
- The report is saved in the output directory with a timestamp.

## Aliases
- `aud` (short)
- `audit:security` (run only security checks – will be added via a separate command later)

## Output
- The final report path is printed to stdout.
- If any critical issues found, the command exits with code 1.
- Example output: