---
name: test
description: Execute test suite with extensive options
arguments:
  - name: filter
    type: string
    required: false
    description: "Test name pattern (regex) to run"
  - name: coverage
    type: boolean
    required: false
    default: false
    description: "Generate coverage report"
  - name: watch
    type: boolean
    required: false
    default: false
    description: "Run in watch mode"
  - name: retry
    type: integer
    required: false
    default: 0
    description: "Number of retries for failed tests"
  - name: parallel
    type: boolean
    required: false
    default: false
    description: "Run tests in parallel (if supported)"
  - name: only-failed
    type: boolean
    required: false
    default: false
    description: "Rerun only previously failed tests"
  - name: verbose
    type: boolean
    required: false
    default: false
    description: "Show full stack traces"
---

# Test Command

## Execution
- Determine test runner from `package.json` (npm test), `pytest.ini` (pytest), `go.mod` (go test), etc.
- Build command:
  - For npm: `npm test -- --testPathPattern=<filter>` or `jest <filter>`.
  - For pytest: `pytest -k <filter> -v --cov` (if coverage).
  - For go: `go test -run <filter> -cover` (if coverage).
- Apply flags: coverage, watch, retry, parallel, only-failed, verbose.

## Additional Steps
- Before test: run `npm run pretest` or similar.
- After test: if coverage enabled, open report (if `--open` flag implicit).
- Save output to `.opencode/test-output-<timestamp>.log`.
- If failures, automatically invoke test-agent for analysis.

## Aliases
- `t` (short for `test`)
- `tc` (test with coverage)
- `tw` (test with watch)

## Environment
- Set `NODE_ENV=test`, `PYTHON_ENV=test`, `GO_ENV=test` to avoid side effects.
- Override any database URL to test instance.

## Hooks
- Pre-test: execute script defined in `.opencode/hooks/pre-test.sh` if exists.
- Post-test: execute `.opencode/hooks/post-test.sh`.

## Errors
- If test runner not found, prompt to install.
- If tests fail, exit with non-zero code (unless `--allow-fail` is set).