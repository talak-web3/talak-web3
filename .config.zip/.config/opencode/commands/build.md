---
name: build
description: Build project artifacts
arguments:
  - name: target
    type: string
    required: false
    description: "Build target (e.g., 'web', 'server', 'cli')"
  - name: release
    type: boolean
    required: false
    default: false
    description: "Optimize for production (minify, strip debug)"
  - name: clean
    type: boolean
    required: false
    default: false
    description: "Clean build directory before building"
  - name: watch
    type: boolean
    required: false
    default: false
    description: "Rebuild on file changes"
---

# Build Command

## Execution
- Detect build tool from `package.json` (npm run build), `Cargo.toml` (cargo build), `go.mod` (go build), etc.
- For release: set `NODE_ENV=production`, `--release` flag for Rust, `-ldflags -s -w` for Go.
- For clean: remove `dist/`, `build/`, `target/`, etc. according to project.
- For watch: use `nodemon` or `cargo watch` or `air`.
- After build, verify existence of expected output files (defined in `.opencode/build-manifest.json`).

## Artifacts
- Package outputs into a tarball or zip if `--package` flag (not shown, but could be added).
- Store build logs in `.opencode/build-log-<timestamp>.txt`.

## Constraints
- Build must not produce errors; if so, abort and show error log.
- If release, run `npm audit` or equivalent to check for vulnerabilities.

## Output