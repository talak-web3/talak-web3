---
name: clean
description: Remove build artifacts, temporary files, and caches
arguments:
  - name: all
    type: boolean
    required: false
    default: false
    description: "Remove all generated files (including node_modules, target, etc.)"
  - name: dry-run
    type: boolean
    required: false
    default: false
    description: "Show what would be deleted without deleting"
---

# Clean Command

## Execution
- Delete directories: dist/, build/, coverage/, .next/, .opencode/cache/ (unless --keep-cache).
- If `--all`: delete node_modules/, target/, venv/, vendor/.
- Use `git clean -xdf` if repository is clean (ask confirmation).
- Dry-run: list files/directories that would be removed.

## Constraints
- Never delete .git/ or .env files.
- Always prompt for confirmation if `--all` is used.

## Output